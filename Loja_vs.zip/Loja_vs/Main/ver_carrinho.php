<?php
require '../src/config/database.php';
require '../src/models/Carrinho.php';

$carrinho = new Carrinho($pdo);
$idCliente = 1; // Troca pelo ID do cliente logado
$itens = $carrinho->listarCarrinho($idCliente);
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Meu Carrinho</title>
</head>
<body>
    <h1>Itens no Carrinho</h1>
    <ul>
        <?php foreach ($itens as $item): ?>
            <li><?php echo $item['nome_produto']; ?> - Quantidade: <?php echo $item['quantidade']; ?></li>
        <?php endforeach; ?>
    </ul>
</body>
</html>
