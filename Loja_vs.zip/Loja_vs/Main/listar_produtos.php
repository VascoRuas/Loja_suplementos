<?php
require '../src/config/database.php';
require '../src/models/Produto.php';

$produto = new Produto($pdo);
$produtos = $produto->listarProdutos();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Lista de Produtos</title>
</head>
<body>
    <h1>Produtos Disponíveis</h1>
    <ul>
        <?php foreach ($produtos as $p): ?>
            <li><?php echo $p['nome_produto']; ?> - €<?php echo $p['preco']; ?></li>
        <?php endforeach; ?>
    </ul>
</body>
</html>

//http://localhost/Loja_vs/Main/listar_produtos.php
