<?php
require '../src/config/database.php';

if ($pdo) {
    echo "Conexão com o banco de dados bem-sucedida!";
} else {
    echo "Erro ao conectar.";
}
?>
*/http://localhost/Loja_vs/Main/testar_connect.php*/
