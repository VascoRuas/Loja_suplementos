<?php
require '../src/config/database.php';
require '../src/models/Carrinho.php';

$carrinho = new Carrinho($pdo);

// Supondo que os valores venham de um formulário
$idCliente = $_POST['id_cliente'];
$idProduto = $_POST['id_produto'];
$quantidade = $_POST['quantidade'];

if ($carrinho->adicionarAoCarrinho($idCliente, $idProduto, $quantidade)) {
    echo "Produto adicionado ao carrinho!";
} else {
    echo "Erro ao adicionar produto.";
}
?>
