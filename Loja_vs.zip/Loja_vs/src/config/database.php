<?php
$host = "localhost";
$dbname = "loja_suplementos";  // Ajustado para o nome correto do banco
$user = "root";  // Usuário padrão do MySQL
$pass = "";  // Senha (modifica se necessário)

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro na conexão: " . $e->getMessage());
}
?>
