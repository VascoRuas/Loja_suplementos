<?php
class Carrinho {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function adicionarAoCarrinho($idCliente, $idProduto, $quantidade) {
        $sql = "INSERT INTO carrinho (id_cliente, id_produto, quantidade) VALUES (:idCliente, :idProduto, :quantidade)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':idCliente', $idCliente);
        $stmt->bindParam(':idProduto', $idProduto);
        $stmt->bindParam(':quantidade', $quantidade);
        return $stmt->execute();
    }

    public function listarCarrinho($idCliente) {
    $sql = "SELECT p.nome_produto, c.quantidade FROM carrinho c
            JOIN produtos p ON c.id_produto = p.id_produto
            WHERE c.id_cliente = :idCliente";
    $stmt = $this->pdo->prepare($sql);
    $stmt->bindParam(':idCliente', $idCliente);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

}
?>

http://localhost/Loja_vs/Main/ver_carrinho.php
